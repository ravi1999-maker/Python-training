student_map = {
    "name": "Name",
    "address": "Address",
    "dob": "Date of Birth",
    "branch": "Branch",
    "cgpa": "CGPA"
}
