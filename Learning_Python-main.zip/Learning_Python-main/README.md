# Specialized Technology Track – Advance Python by Xoriant

### -> Day 1: PyMongo [Code + Practice Assignment]
### -> Day 2: Flask
### -> Day 3/ Day4/ Day5/ Day 6: Advanced Python [includes notebooks and codes + Practice codes]
### -> Day 6: XML + AgrParse
### -> Day 7: AgrParse Cont... + Networking + Templating